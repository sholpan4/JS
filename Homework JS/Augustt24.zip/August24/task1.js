var a = Number(prompt("Введите число начало диапазона: "));
var b = Number(prompt("Введите число конец диапазона: "));
var sum = 0;
 
while(a < b){
    a++;
    sum += a;      
    }

alert(sum)